<!DOCTYPE html>
<html>
<head>
    <title>Booking Successful</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
</head>
<body class="p-5">
<div class="container">
    <div class="alert alert-success">
        <h4>Booking Successful!</h4>
        <p>Your room has been booked. Admin can now see it in the booking list.</p>
    </div>
    <a href="room.php" class="btn btn-primary">Back to Rooms</a>
</div>
</body>
</html>
