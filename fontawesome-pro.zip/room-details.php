<?php
include_once('db_config.php');
session_start();

/* ---------- VALIDATE ROOM ID ---------- */
if (!isset($_GET['room_id']) || !is_numeric($_GET['room_id'])) {
  header('Location: room.php');
  exit;
}

$room_id = (int) $_GET['room_id'];

/* ---------- HANDLE BOOKING ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['nights'])) {

  // Generate random guest ID if not logged in
  if (isset($_SESSION['customer_id'])) {
    $customer_id = $_SESSION['customer_id'];
  } else {
    $customer_id = 'GUEST-' . rand(100000, 999999);
  }

  $nights = (int) $_POST['nights'];
  $price = (float) $_POST['price'];

  // Check room availability again
  $checkRoom = $conn->prepare(
    "SELECT status FROM rooms WHERE room_id = ?"
  );
  $checkRoom->bind_param("i", $room_id);
  $checkRoom->execute();
  $roomStatus = $checkRoom->get_result()->fetch_assoc();

  if ($roomStatus['status'] !== 'Available') {
    $_SESSION['error'] = "Room is no longer available.";
    header("Location: room_details.php?room_id=$room_id");
    exit;
  }

  $check_in = date('Y-m-d');
  $check_out = date('Y-m-d', strtotime("+$nights days"));
  $total_price = $price * $nights;

  // Insert booking
  $insertBooking = $conn->prepare(
    "INSERT INTO bookings
        (room_id, customer_id, check_in, check_out, total_price, booking_status)
        VALUES (?, ?, ?, ?, ?, 'Booked')"
  );
  $insertBooking->bind_param(
    "isssd",
    $room_id,
    $customer_id,
    $check_in,
    $check_out,
    $total_price
  );
  $insertBooking->execute();

  // Update room status
  $updateRoom = $conn->prepare(
    "UPDATE rooms SET status = 'Booked' WHERE room_id = ?"
  );
  $updateRoom->bind_param("i", $room_id);
  $updateRoom->execute();

  $_SESSION['success'] = "Room booked successfully! Your ID: $customer_id";
  header("Location: room.php");
  exit;
}


/* ---------- FETCH ROOM INFO ---------- */
$stmt = $conn->prepare(
  "SELECT r.room_id, r.room_number, r.status,
            c.category_name, c.price,
            ri.image_url
     FROM rooms r
     JOIN room_categories c ON r.category_id = c.category_id
     LEFT JOIN room_images ri ON r.room_id = ri.room_id
     WHERE r.room_id = ?
     LIMIT 1"
);
$stmt->bind_param("i", $room_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
  header('Location: room.php');
  exit;
}

$room = $result->fetch_assoc();
?>

<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <title>Room Details</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/style.css">
</head>

<body>
  <?php include_once 'Inc/top_nav.php'; ?>

  <main style="padding-top:200px; padding-bottom:100px">
    <div class="container">

      <a href="room.php" class="btn btn-secondary mb-4">&larr; Back to Rooms</a>

      <?php
      if (isset($_SESSION['error'])) {
        echo "<div class='alert alert-danger'>{$_SESSION['error']}</div>";
        unset($_SESSION['error']);
      }
      ?>

      <div class="row">
        <div class="col-md-6">
          <img src="./Admin/<?= htmlspecialchars($room['image_url']) ?>"
            class="img-fluid"
            style="height:250px; object-fit:cover;">
        </div>

        <div class="col-md-6">
          <h2>Room <?= htmlspecialchars($room['room_number']) ?></h2>
          <p><strong>Category:</strong> <?= htmlspecialchars($room['category_name']) ?></p>
          <p><strong>Price per night:</strong> $<?= number_format($room['price'], 2) ?></p>
          <p>
            <strong>Status:</strong>
            <span class="badge 
                <?= $room['status'] === 'Available' ? 'badge-success' : ($room['status'] === 'Occupied' ? 'badge-danger' : 'badge-warning'); ?>">
              <?= $room['status'] ?>
            </span>
          </p>

          <form method="POST">
            <input type="hidden" name="price" value="<?= $room['price'] ?>">

            <div class="form-group">
              <label>Number of nights</label>
              <select name="nights" class="form-control" required>
                <?php for ($i = 1; $i <= 30; $i++): ?>
                  <option value="<?= $i ?>">
                    <?= $i ?> <?= $i == 1 ? 'night' : 'nights' ?>
                  </option>
                <?php endfor; ?>
              </select>
            </div>

            <button type="submit"
              class="btn btn-primary mt-3"
              <?= $room['status'] !== 'Available' ? 'disabled' : '' ?>>
              Book Now
            </button>

            <?php if ($room['status'] !== 'Available'): ?>
              <small class="text-danger d-block mt-2">
                This room is not available.
              </small>
            <?php endif; ?>
          </form>
        </div>
      </div>
    </div>
  </main>

  <?php include_once 'Inc/footer.php'; ?>

  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.bundle.min.js"></script>
</body>

</html>